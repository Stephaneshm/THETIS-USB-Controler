var searchData=
[
  ['pin_15',['pin',['../class_bounce.html#a1cb79cb0ba2379cd12cc7c098d97053a',1,'Bounce']]],
  ['pressed_16',['pressed',['../class_bounce2_1_1_button.html#a61541ae21354cb7f5cc5bc8c05db59dd',1,'Bounce2::Button']]],
  ['previousduration_17',['previousDuration',['../class_debouncer.html#ac6af22dc9c6ae84462fe356b7430659e',1,'Debouncer']]]
];
